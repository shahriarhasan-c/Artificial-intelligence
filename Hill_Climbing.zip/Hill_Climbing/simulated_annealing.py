import math
import random


def move_or_not(d, s_t, s_l):
    x = math.exp(d)
    R = random.uniform(0, 1)
    if R >= 0 and R <= 0.15:
        State_generation(s_t, s_l)


def State_generation(current_state, current_state_cost):
    c = 0
    a = 0
    s_sum = 112323
    t_f = []
    temp = []
    for x in current_state:
        c = a+1
        for y in current_state:
            temp = list(current_state)
            if(c <= 9):
                temp[a], temp[c] = temp[c], temp[a]
                c += 1
                sum = calc_cost(temp)
                t1 = list(temp)
                if(s_sum > sum):
                    s_sum = sum
                    t_f = list(temp)
                    s_sum = sum

                temp.clear()
        a += 1
    if s_sum < cost:
        return t_f, s_sum
    else:
        si = s_sum
        s_t, s_l = State_generation(t_f, s_sum)
        if s_l < si:
            s_t, s_l = State_generation(s_t, s_l)
        elif s_l == si:
            de = -1
            move_or_not(de, s_t, s_l)
        else:
            de = si - State_generation(s_t, s_l)
            move_or_not(de, s_t, s_l)



def calc_cost(s):
    c = 1
    sum = 0
    for x in s:
        temp = s[c:]
        c += 1
        for y in temp:
            if y < x:
                sum += 1
    return sum

def goal_test(s):
    if calc_cost(s) == 0:
        return True
    else:
        return False


state = [2, 1, 5, 0, 8, 4, 10, 0, 20, 10]
t = list(state)
while(goal_test(t) == False):
    cost = calc_cost(t)
    t, co = State_generation(t, cost)
    if co is None:
        print(t)
        break
print(t)
